package com.angrybird.nazare;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.utils.viewport.StretchViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.angrybird.chidiaghussemainhai;


public class heads_up_display {

    public Stage Platform;
    private Viewport dekhnekeliyeport;

    private Integer worldkeliyetimer;
    private float Time____Count;
    private Integer Scoore;

    Label countdownkeliyelabel;
    Label scorekeliyelabel;
    Label timekeliyeLabel;
    Label LevelkeliyeLabel;
    Label world_______label;
    Label bird___Label;

    public heads_up_display(SpriteBatch s____b) {
        worldkeliyetimer = 300;
        Time____Count = 0;
        Scoore = 0;

        dekhnekeliyeport = new StretchViewport(chidiaghussemainhai.widthh, chidiaghussemainhai.heightt, new OrthographicCamera());
        Platform = new Stage(dekhnekeliyeport, s____b);

        Table table = new Table();
        table.top();
        table.setFillParent(true);

        countdownkeliyelabel = new Label(String.format("%03d", worldkeliyetimer),
            new Label.LabelStyle(new BitmapFont(), Color.WHITE));
        scorekeliyelabel = new Label(String.format("%06d", Scoore),
            new Label.LabelStyle(new BitmapFont(), Color.WHITE));
        timekeliyeLabel = new Label(String.format("TIME"),
            new Label.LabelStyle(new BitmapFont(), Color.WHITE));
        LevelkeliyeLabel = new Label(String.format("1-1"),
            new Label.LabelStyle(new BitmapFont(), Color.WHITE));
        world_______label = new Label(String.format("WORLD"),
            new Label.LabelStyle(new BitmapFont(), Color.WHITE));
        bird___Label = new Label(String.format("CHIDIYAAN"),
            new Label.LabelStyle(new BitmapFont(), Color.WHITE));

        table.add(bird___Label).expandX().padTop(10);
        table.add(world_______label).expandX().padTop(10);
        table.add(timekeliyeLabel).expandX().padTop(10);
        table.row();
        table.add(scorekeliyelabel).expandX();
        table.add(LevelkeliyeLabel).expandX();
        table.add(countdownkeliyelabel).expandX();

        Platform.addActor(table);
    }
}
