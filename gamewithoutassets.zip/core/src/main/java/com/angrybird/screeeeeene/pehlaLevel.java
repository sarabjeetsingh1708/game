package com.angrybird.screeeeeene;

import com.angrybird.jivjantu.*;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.InputProcessor;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.*;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.utils.viewport.StretchViewport;
import com.badlogic.gdx.utils.viewport.Viewport;

import java.util.ArrayList;
import java.util.List;

public class pehlaLevel implements Screen, InputProcessor {

    private final JeetnekiScreen.GussaelChidyaan game;
    private Stage sttaagge;
    private Texture Texturelogo;
    private Table Table_menu;
    public Viewport game__port = shuruatkiScreen.game____port;

    private blackbird.redbird redBird;
    private blackbird.redbird redBird1;
    private blackbird.redbird redbird2;
    private blackbird.redbird[] birds;
    private blackbird.redbird currentBird;
    private int currentBirdIndex = 2; // Start with redBird2

    private catapult catapult;
    private kanch kanch1;
    private kanch kanch2;
    private kanch kanch3;
    private Piggiess piggiess1;
    private Piggiess piggiess2;

    private final float circleCenterX = 320;
    private final float circleCenterY = 460;
    private final float circleRadius = 85;


    private static final float gravity = -9.81f * 1000;
    private static final float MAX_VELOCITY = 800f;
    private boolean show_trajectory = false;
    private Vector2 Velocity_launch = new Vector2();

    private static final float falling_gravity = 500f; // Gravity for falling objects
    private static final float GROUND_LEVEL = 300f;
    private List<kanch> kanchList = new ArrayList<>();
    private List<Piggiess> piggiessList = new ArrayList<>();
    private List<Actor> fallingObjects = new ArrayList<>();

    private World world;
    private Box2DDebugRenderer debugRenderer;
    private static final float PPM = 100f;

    private static final float BOUNCE_DURATION = 0.5f;
    private static final float BOUNCE_HEIGHT = 100f;
    private boolean isAnimating = false;
    private float animationTime = 0f;
    private Vector2 startPosition = new Vector2();
    private Vector2 endPosition = new Vector2();


    private ShapeRenderer shapeRenderer;


    public pehlaLevel(JeetnekiScreen.GussaelChidyaan game) {
        this.game = game;
        sttaagge = new Stage(new StretchViewport(1820, 980));
        Gdx.input.setInputProcessor(sttaagge);
        shapeRenderer = new ShapeRenderer();

        Texturelogo = new Texture(Gdx.files.internal("level_back.jpg"));

        Worldkointializekaro();
        AllObjectskointilaizekaro();
        Birdskointializekaro();

    }

    private void Birdskointializekaro() {

        BodyDef Defbody = new BodyDef();

        redBird = new blackbird.redbird();
        Defbody.type = BodyDef.BodyType.DynamicBody;
        Defbody.position.set(100, 300);

        Body red_Bird_body = world.createBody(Defbody);

        CircleShape shape = new CircleShape();
        shape.setRadius(redBird.getWidth() * 0.05f);

        FixtureDef redbird_fix = new FixtureDef();
        redbird_fix.shape = shape;
        redbird_fix.density = 1.0f;
        redbird_fix.restitution = 0.3f;
        redbird_fix.friction = 0.2f;

        red_Bird_body.createFixture(redbird_fix);
//        shape.dispose();

        red_Bird_body.setUserData(redBird);

        redBird1 = new blackbird.redbird();
        Defbody.type = BodyDef.BodyType.DynamicBody;
        Defbody.position.set(200, 300);

        Body redBird1_body = world.createBody(Defbody);

        FixtureDef redbird1_fix = new FixtureDef();
        redbird1_fix.shape = shape;
        redbird1_fix.density = 1.0f;
        redbird1_fix.restitution = 0.3f;
        redbird1_fix.friction = 0.2f;

        redBird1_body.createFixture(redbird1_fix);
//        shape.dispose();

        redBird1_body.setUserData(redBird1);

        redbird2 = new blackbird.redbird();
//        redBird2.setPosition(CIRCLE_CENTER_X, CIRCLE_CENTER_Y);
//        redBird2.setSize(redBird.getWidth(), redBird.getHeight());
        Defbody.type = BodyDef.BodyType.DynamicBody;
        Defbody.position.set(circleCenterX, circleCenterY);

        Body redBird2_body = world.createBody(Defbody);

        FixtureDef red_bird2_fix = new FixtureDef();
        red_bird2_fix.shape = shape;
        red_bird2_fix.density = 1.0f;
        red_bird2_fix.restitution = 0.3f;
        red_bird2_fix.friction = 0.2f;

        redBird2_body.createFixture(red_bird2_fix);
//        shape.dispose();

        redBird2_body.setUserData(redbird2);


        birds = new blackbird.redbird[]{redBird, redBird1, redbird2};
        currentBird = birds[currentBirdIndex];

        startPosition.set(200, 300);
        endPosition.set(circleCenterX, circleCenterY);


    }

    private void AllObjectskointilaizekaro() {
        catapult = new catapult();
        catapult.setPosition(300, 300);

        BodyDef temp = new BodyDef();

        kanch1 = new kanch();

        temp.type = BodyDef.BodyType.DynamicBody;

        temp.position.set(1200, 360);
        temp.position.rotate90(1);

        Body seesha1_body = world.createBody(temp);


        PolygonShape shape = new PolygonShape();
        shape.setAsBox(kanch1.getWidth() * 0.075f, kanch1.getHeight() * 0.075f);
        FixtureDef kanch1_fix = new FixtureDef();
        kanch1_fix.shape = shape;
        kanch1_fix.density = 1.0f;
        kanch1_fix.friction = 0.5f;
        kanch1_fix.restitution = 0.2f;

        seesha1_body.createFixture(kanch1_fix);
        seesha1_body.setUserData(kanch1);
        shape.dispose();



        kanch2 = new kanch();
        kanch2.setPosition(1200, 490);
        kanch2.setRotation(90);
        kanch2.setSize(kanch1.getWidth(), kanch1.getHeight());

        temp.type = BodyDef.BodyType.DynamicBody;

        temp.position.set(1200, 490);
        temp.position.rotate90(1);

        Body seesha2_body = world.createBody(temp);

        shape.setAsBox(kanch1.getWidth(), kanch1.getHeight());
        FixtureDef kanch2_fix = new FixtureDef();
        kanch2_fix.shape = shape;
        kanch2_fix.density = 1.0f;
        kanch2_fix.friction = 0.5f;
        kanch2_fix.restitution = 0.2f;

        seesha2_body.createFixture(kanch2_fix);
        seesha2_body.setUserData(kanch2);
        shape.dispose();

        kanch3 = new kanch();
//        kanch3.setPosition(1200, 563);
//        kanch3.setSize(kanch1.getWidth(), kanch1.getHeight());

        temp.type = BodyDef.BodyType.DynamicBody;

        temp.position.set(1200, 563);

        Body seesha3_body = world.createBody(temp);


        PolygonShape shape2 = new PolygonShape();
        shape.setAsBox(kanch1.getWidth() , kanch1.getHeight());
        FixtureDef seesha3_fix = new FixtureDef();
        seesha3_fix.shape = shape;
        seesha3_fix.density = 1.0f;
        seesha3_fix.friction = 0.5f;
        seesha3_fix.restitution = 0.2f;

        seesha3_body.createFixture(seesha3_fix);
        seesha3_body.setUserData(kanch3);
        shape.dispose();

        piggiess1 = new Piggiess();


        temp.type = BodyDef.BodyType.DynamicBody;
        temp.position.set(1200,580);
        Body suar1_body = world.createBody(temp);

        CircleShape shape1 = new CircleShape();
        shape1.setRadius(piggiess1.getWidth() * 0.2f);

        FixtureDef fixtureDef = new FixtureDef();
        fixtureDef.shape = shape1;
        fixtureDef.density = 1.0f;
        fixtureDef.restitution = 0.3f;
        fixtureDef.friction = 0.2f;

        piggiess2 = new Piggiess();
        temp.type = BodyDef.BodyType.DynamicBody;
        temp.position.set(1200,580);
        Body suar2_body = world.createBody(temp);

        FixtureDef fixtureDef1 = new FixtureDef();
        fixtureDef1.shape = shape1;
        fixtureDef1.density = 1.0f;
        fixtureDef1.restitution = 0.3f;
        fixtureDef1.friction = 0.2f;

        suar2_body.setUserData(piggiess2);
        suar1_body.setUserData(piggiess1);

    }


    private void Worldkointializekaro() {
        this.world = new World(new Vector2(0, gravity), true);
        this.debugRenderer = new Box2DDebugRenderer();

        BodyDef zameen = new BodyDef();
        zameen.position.set(0, 0);
        Body zameen_body = world.createBody(zameen);

        EdgeShape groundShape = new EdgeShape();
        groundShape.set(0, 0, sttaagge.getWidth(), 300);

        FixtureDef fixtureDef = new FixtureDef();
        fixtureDef.shape = groundShape;
        fixtureDef.friction = 10.0f;
        fixtureDef.restitution = 0.1f;

        zameen_body.createFixture(fixtureDef);
        groundShape.dispose();}


    public void handleBirdSeeshaCollisions(blackbird.redbird bird, kanch seeshaa) {



    }

    @Override
    public boolean keyDown(int i) {
        return false;
    }

    @Override
    public boolean keyUp(int i) {
        return false;
    }

    @Override
    public boolean keyTyped(char c) {
        return false;
    }

    @Override
    public boolean touchDown(int i, int i1, int i2, int i3) {
        return false;
    }

    @Override
    public boolean touchUp(int i, int i1, int i2, int i3) {
        return false;
    }

    @Override
    public boolean touchCancelled(int i, int i1, int i2, int i3) {
        return false;
    }

    @Override
    public boolean touchDragged(int i, int i1, int i2) {
        return false;
    }

    @Override
    public boolean mouseMoved(int i, int i1) {
        return false;
    }

    @Override
    public boolean scrolled(float v, float v1) {
        return false;
    }

    @Override
    public void show() {

    }

    @Override
    public void render(float v) {

    }

    @Override
    public void resize(int i, int i1) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }
}

