package com.angrybird.screeeeeene;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.viewport.StretchViewport;
import com.angrybird.chidiaghussemainhai;

public class LevelkiScreenchunoo implements Screen {
    private final chidiaghussemainhai game;
    private Stage staaggge;
    private Texture texturelogo;
    private Texture[] leveltextures;
    private Texture close_button__texture;
    private Texture Buttondummy;
    private Table Tablemain;

    public LevelkiScreenchunoo(chidiaghussemainhai game) {
        this.game = game;
        staaggge = new Stage(new StretchViewport(1820, 980));
        Gdx.input.setInputProcessor(staaggge);

        texturelogo = new Texture(Gdx.files.internal("levelmenuscreen.png"));

        leveltextures = new Texture[]{
            new Texture(Gdx.files.internal("level1button.png")),
            new Texture(Gdx.files.internal("level2button.png")),
            new Texture(Gdx.files.internal("level3button.png")),
            new Texture(Gdx.files.internal("level4button.png"))
        };

        ImageButton[] levelButtons = new ImageButton[leveltextures.length];
        for (int i = 0; i < leveltextures.length; i++) {
            TextureRegionDrawable drawable = new TextureRegionDrawable(leveltextures[i]);
            levelButtons[i] = new ImageButton(drawable);
            int levelIndex = i;
            levelButtons[i].addListener(new ClickListener() {
                @Override
                public void clicked(InputEvent event, float x, float y) {
                    switch (levelIndex) {
                        case 0:
                            game.setScreen(new pehlelevelkiscreenn(game));
                            break;
                        case 1:
                            // game.setScreen(new Level2Screen(game));
                            break;
                        case 2:
                            // game.setScreen(new Level3Screen(game));
                            break;
                        case 3:
                            // game.setScreen(new Level4Screen(game));
                            break;
                    }
                }
            });
        }

        Tablemain = new Table();
        Tablemain.center();
        for (ImageButton levelButton : levelButtons) {
            Tablemain.add(levelButton).size(200, 600).pad(25);
        }

        Texture backButtonTexture = new Texture(Gdx.files.internal("goback.png"));
        TextureRegionDrawable backDrawable = new TextureRegionDrawable(backButtonTexture);
        ImageButton Buttonback = new ImageButton(backDrawable);
        Buttonback.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                game.setScreen(new shuruatkiScreen(game));
            }
        });

        close_button__texture = new Texture(Gdx.files.internal("quitButtonFINAL.png"));
        TextureRegionDrawable Drawableclose = new TextureRegionDrawable(close_button__texture);
        ImageButton closeButton = new ImageButton(Drawableclose);
        closeButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                Gdx.app.exit();
            }
        });


        Buttondummy = new Texture(Gdx.files.internal("SettingButton.png"));
        TextureRegionDrawable dummyy = new TextureRegionDrawable(Buttondummy);
        ImageButton dummyButton = new ImageButton(dummyy);
        dummyButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
//                Gdx.app.exit();
                System.out.println("Dummy Clicked");
                game.setScreen(new JeetnekiScreen(game));

            }
        });

        Buttonback.setSize(50, 50);
        Buttonback.setPosition(staaggge.getWidth() - 60, 10);

        closeButton.setSize(100, 100);
        closeButton.setPosition(staaggge.getWidth() - 110, staaggge.getHeight() - 110);

        dummyButton.setSize(200, 200);
        dummyButton.setPosition(20, 200);

        staaggge.addActor(Tablemain);
        staaggge.addActor(Buttonback);
        staaggge.addActor(closeButton);
        staaggge.addActor(dummyButton);
    }

    @Override
    public void show() {}

    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(1, 1, 1, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        game.batttch.setProjectionMatrix(staaggge.getCamera().combined);
        game.batttch.begin();
        game.batttch.draw(texturelogo, 0, 0, staaggge.getWidth(), staaggge.getHeight());
        game.batttch.end();

        staaggge.act();
        staaggge.draw();
    }

    @Override
    public void resize(int width, int height) {
        staaggge.getViewport().update(width, height, true);
        Tablemain.setPosition(staaggge.getWidth() / 2, staaggge.getHeight() / 2 - 200);
    }

    @Override
    public void pause() {}

    @Override
    public void resume() {}

    @Override
    public void hide() {}

    @Override
    public void dispose() {
        staaggge.dispose();
        texturelogo.dispose();
        for (Texture texture : leveltextures) {
            texture.dispose();
        }
        close_button__texture.dispose();
    }
}
