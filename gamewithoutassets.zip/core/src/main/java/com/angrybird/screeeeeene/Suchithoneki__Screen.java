package com.angrybird.screeeeeene;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.viewport.StretchViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.angrybird.chidiaghussemainhai;

public class Suchithoneki__Screen implements Screen {
    private final chidiaghussemainhai gaaammmeee;
    private Stage platform;
    private Texture Texturelogokaa;
    private Texture nextButtonkaTexture;
    private Texture signupButtonkeliyeTexture;
    private Table main___Table;
    public Viewport game____port = shuruatkiScreen.game____port;
    public OrthographicCamera game__camerraa = shuruatkiScreen.game__camerraa;

    public Suchithoneki__Screen(chidiaghussemainhai gaaammmeee) {
        this.gaaammmeee = gaaammmeee;
        platform = new Stage(new StretchViewport(1820, 980));
        Gdx.input.setInputProcessor(platform);

        Texturelogokaa = new Texture(Gdx.files.internal("loginpage.png"));


        nextButtonkaTexture = new Texture(Gdx.files.internal("nextbutton.png"));


        TextureRegionDrawable next___drawable___ = new TextureRegionDrawable(nextButtonkaTexture);
        ImageButton aglaButton = new ImageButton(next___drawable___);


        aglaButton.addListener(new ClickListener() {
            @Override
            public void clicked(com.badlogic.gdx.scenes.scene2d.InputEvent event, float x, float y) {
                System.out.println("Next button clicked");
                gaaammmeee.setScreen(new LevelkiScreenchunoo(gaaammmeee));
            }
        });


        main___Table = new Table();
        main___Table.center();
        main___Table.add(aglaButton).size(300, 200).pad(25);
        main___Table.row();


        Texture backButtonkeliyeTexture = new Texture(Gdx.files.internal("goback.png"));
        TextureRegionDrawable back____Drawable = new TextureRegionDrawable(backButtonkeliyeTexture);
        ImageButton picheka__Button = new ImageButton(back____Drawable);


        picheka__Button.addListener(new ClickListener() {
            @Override
            public void clicked(com.badlogic.gdx.scenes.scene2d.InputEvent event, float x, float y) {
                System.out.println("Back button clickedddd");
                gaaammmeee.setScreen(new shuruatkiScreen(gaaammmeee));
            }
        });


        picheka__Button.setSize(50, 50);
        picheka__Button.setPosition(platform.getWidth() - 60, 10);

        platform.addActor(main___Table);
        platform.addActor(picheka__Button);
    }

    @Override
    public void show() {}

    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(1, 1, 1, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        gaaammmeee.batttch.setProjectionMatrix(platform.getCamera().combined);
        gaaammmeee.batttch.begin();
        gaaammmeee.batttch.draw(Texturelogokaa, 0, 0, platform.getWidth(), platform.getHeight());
        gaaammmeee.batttch.end();

        platform.act();
        platform.draw();
    }

    @Override
    public void resize(int width, int height) {
        platform.getViewport().update(width, height, true);

        main___Table.setSize(200, 100);
        main___Table.setPosition(game____port.getWorldWidth() / 2 - 60, game____port.getWorldHeight() / 2 - 370);
    }

    @Override
    public void pause() {}

    @Override
    public void resume() {}

    @Override
    public void hide() {}

    @Override
    public void dispose() {
        platform.dispose();
        Texturelogokaa.dispose();
        nextButtonkaTexture.dispose();
    }
}
