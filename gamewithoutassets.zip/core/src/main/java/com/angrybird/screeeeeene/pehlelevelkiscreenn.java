package com.angrybird.screeeeeene;

import com.angrybird.jivjantu.*;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer.ShapeType;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.*;
import com.badlogic.gdx.physics.box2d.BodyDef.BodyType;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.InputListener;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.viewport.StretchViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.angrybird.chidiaghussemainhai;

import java.util.ArrayList;
import java.util.List;

public class pehlelevelkiscreenn implements Screen {
    private final chidiaghussemainhai gamme;
    private Stage platform;
    private Texture Texturelogo;
    private Table Tablemain;
    public Viewport gameport = shuruatkiScreen.game____port;

    private blackbird.redbird redBird;
    private blackbird.redbird redBird1;
    private blackbird.redbird redBird2;
    private blackbird.redbird[] birds;
    private blackbird.redbird current______Bird;
    private int currentBirdIndex = 2; // Start with redBird2

    private catapult catapult;
    private kanch kanch1;
    private kanch kanch2;
    private kanch kanch3;
    private Piggiess piggiess1;
    private Piggiess piggiess2;

    private float dragOffsetX, dragOffsetY;
    private boolean kyaDragginghorahihai = false;
    private boolean kyaLaunchedhua = false;
    private boolean kyaKhatamhua = false;
    private float launchTime = 0;
    private Vector2 positioon = new Vector2();
    private Vector2 speed = new Vector2();

    // Animation related fields
    private static final float BOUNCE_duration = 0.5f;
    private static final float BOUNCE_height = 100f;
    private boolean kyaAnimatinghorahihai = false;
    private float animationkaTime = 0f;
    private Vector2 start__Position = new Vector2();
    private Vector2 end___Position = new Vector2();

    private final float circleCenterX = 320;
    private final float circleCenterY = 460;
    private final float circleRadius = 85;

    // Trajectory-related fields
    private ShapeRenderer shaperenderer;
    private static final int TRAJECTORY_POINTS = 20;
    private static final float gravity = -9.81f * 1000;
    private static final float MAXIMUM_VELOCITY = 800f;
    private boolean show___Trajectory = false;
    private Vector2 launch____Velocity = new Vector2();

    private static final float FALLllllING_GRAVITY = 500f; // Gravity for falling objects
    private static final float ground_LEVEL = 300f;
    private List<kanch> kanchList = new ArrayList<>();
    private List<Piggiess> piggiessList = new ArrayList<>();
    private List<Actor> girtihui__Objects = new ArrayList<>();

    private World world;
    private Box2DDebugRenderer dDebugRenderer;
    private static final float PPM = 100f;

    public pehlelevelkiscreenn(chidiaghussemainhai gamme) {
        this.gamme = gamme;
        platform = new Stage(new StretchViewport(1820, 980));
        Gdx.input.setInputProcessor(platform);
        shaperenderer = new ShapeRenderer();

        Texturelogo = new Texture(Gdx.files.internal("level_back.jpg"));
        Tablemain = new Table();
        Tablemain.center();



        initializekarooo__Objects();
        initializekaroBirdsko();
        setupkaroButtonsko();
        BirdInputListenerkosetupkaro();
        kanchList.add(kanch1);
        kanchList.add(kanch2);
        kanchList.add(kanch3);
        piggiessList.add(piggiess1);
        piggiessList.add(piggiess2);

        world = new World(new Vector2(0, -9.81f), true);
        dDebugRenderer = new Box2DDebugRenderer();

        // Create physics bodies for all objects
        createPhysicsofjivjantu();
        // Add all actors to stage
        ActorskoaddkaroToPlatform();
    }

    private void createPhysicsofjivjantu() {
        // Create body definition
        BodyDef bodyDef = new BodyDef();
        bodyDef.type = BodyType.DynamicBody;

        // Fixture definition
        FixtureDef fixtureDef = new FixtureDef();
        fixtureDef.density = 1f;
        fixtureDef.friction = 0.5f;
        fixtureDef.restitution = 0.3f;

        // Create physics body for birds
        BirdPhysicsBodycreate(redBird, bodyDef, fixtureDef);
        BirdPhysicsBodycreate(redBird1, bodyDef, fixtureDef);
        BirdPhysicsBodycreate(redBird2, bodyDef, fixtureDef);

        // Create physics bodies for seeshas
        ObjectPhysics_____Bodycreate(kanch1, bodyDef, fixtureDef);
        ObjectPhysics_____Bodycreate(kanch2, bodyDef, fixtureDef);
        ObjectPhysics_____Bodycreate(kanch3, bodyDef, fixtureDef);

        // Create physics bodies for suars
        ObjectPhysics_____Bodycreate(piggiess1, bodyDef, fixtureDef);
        ObjectPhysics_____Bodycreate(piggiess2, bodyDef, fixtureDef);

        // Create ground body
        GroundBodycreate();
    }

    private void BirdPhysicsBodycreate(blackbird.redbird bird, BodyDef bodyDef, FixtureDef fixtureDef) {
        // Set initial position for body
        bodyDef.position.set(bird.getX() / PPM, bird.getY() / PPM);

        // Create body
        Body birdBody = world.createBody(bodyDef);

        // Create circular shape for bird
        CircleShape circleShape = new CircleShape();
        circleShape.setRadius(bird.getWidth() / (2 * PPM));

        // Set shape to fixture
        fixtureDef.shape = circleShape;

        // Create fixture and attach to body
        birdBody.createFixture(fixtureDef);

        // Store body reference in the bird object
        bird.bodyset(birdBody);

        // Debug print
        System.out.println("Bird Physics Body Created - Initial Position: " +
            birdBody.getPosition().x * PPM + ", " +
            birdBody.getPosition().y * PPM);

        // Cleanup
        circleShape.dispose();
    }

    private void ObjectPhysics_____Bodycreate(Actor object, BodyDef bodyDef, FixtureDef fixtureDef) {
        // Set initial position for body
        bodyDef.position.set(object.getX() / PPM, object.getY() / PPM);

        // Create body
        Body objectBody = world.createBody(bodyDef);

        // Create polygon shape
        PolygonShape boxShape = new PolygonShape();
        boxShape.setAsBox(object.getWidth() / (2 * PPM), object.getHeight() / (2 * PPM));

        // Set shape to fixture
        fixtureDef.shape = boxShape;

        // Create fixture and attach to body
        objectBody.createFixture(fixtureDef);

        // If the object has a setBody method, use it (you'll need to modify relevant classes)
        if (object instanceof kanch) {
            ((kanch) object).setBodddddy(objectBody);
        } else if (object instanceof Piggiess) {
            ((Piggiess) object).setBody(objectBody);
        }

        // Cleanup
        boxShape.dispose();
    }

    private void GroundBodycreate() {
        BodyDef groundBodyDef = new BodyDef();
        groundBodyDef.position.set(platform.getWidth() / (2 * PPM), ground_LEVEL / PPM);
//        groundBodyDef.type = BodyType.STATIC;
        groundBodyDef.type = BodyType.StaticBody;

        Body groundBody = world.createBody(groundBodyDef);

        PolygonShape groundShape = new PolygonShape();
        // Wide ground to cover entire screen
        groundShape.setAsBox(platform.getWidth() / (2 * PPM), 10f / PPM);

        FixtureDef groundFixtureDef = new FixtureDef();
        groundFixtureDef.shape = groundShape;
        groundFixtureDef.friction = 0.9f;  // High friction for ground

        groundBody.createFixture(groundFixtureDef);

        groundShape.dispose();
    }


    private void ObjectPositionskoupdatekardo() {
        // Update bird positions
        update___Object____Position(redBird);
        update___Object____Position(redBird1);
        update___Object____Position(redBird2);

        // Update seesha positions
        update___Object____Position(kanch1);
        update___Object____Position(kanch2);
        update___Object____Position(kanch3);

        // Update suar positions
        update___Object____Position(piggiess1);
        update___Object____Position(piggiess2);
    }

    private void update___Object____Position(Actor object) {
        Body body = null;

        // Determine the body based on object type
        if (object instanceof blackbird.redbird) {
            body = ((blackbird.redbird) object).Bodykogetkaro();
        }

        // If body exists, update position
        if (body != null) {
            Vector2 bodyPosition = body.getPosition();
            float newY = Math.max(bodyPosition.y * PPM, ground_LEVEL);

            System.out.println("Updating Bird Position - Physics Body: " +
                bodyPosition.x * PPM + ", " + bodyPosition.y * PPM +
                " | Set Position: " +
                bodyPosition.x * PPM + ", " + newY);

            object.setPosition(
                bodyPosition.x * PPM,
                newY
            );

            // Stop vertical movement when reaching ground
            if (newY <= ground_LEVEL) {
                body.setLinearVelocity(body.getLinearVelocity().x, 0);
            }
        }
    }

    private void handleSeeshaCollision(kanch kanch) {
        if (kanch != null && !kanch.isKyadestryhua()) {
            kanch.girnachaluhua();
            kanchList.remove(kanch);

            if (!girtihui__Objects.contains(kanch)) {
                girtihui__Objects.add(kanch);
            }

            checkandupdatekarofallingobjectsko(kanch);
        }
    }

    private void handle___Suar___Collision(Piggiess piggiess) {
        if (piggiess != null && !piggiess.isKyanashthua()) {
            piggiess.start____falling();
            piggiessList.remove(piggiess);

            if (!girtihui__Objects.contains(piggiess)) {
                girtihui__Objects.add(piggiess);
            }

            checkandupdatekarofallingobjectsko(piggiess);
        }
    }

    private void updatekarofallingobjects(float delta) {
        if (girtihui__Objects.isEmpty()) {
            return;
        }

        System.out.println("Updating falling objects: " + girtihui__Objects.size());

        List<Actor> objectsToRemove = new ArrayList<>();

        for (Actor obj : girtihui__Objects) {
            System.out.println("Processing falling object: " + obj.getClass().getSimpleName());

            if (obj instanceof kanch) {
                kanch kanch = (kanch) obj;
                System.out.println("Before update - kanch Y: " + kanch.getY() +
                    ", Falling: " + kanch.isKyagirrhahai() +
                    ", Destroyed: " + kanch.isKyadestryhua());

                kanch.updddddate(delta);

                System.out.println("After update - kanch Y: " + kanch.getY());
            }

            if (obj instanceof Piggiess) {
                Piggiess piggiess = (Piggiess) obj;
                System.out.println("Before update - Piggiess Y: " + piggiess.getY() +
                    ", Falling: " + piggiess.isFalling());

                piggiess.updddddate(delta);

                System.out.println("After update - Piggiess Y: " + piggiess.getY());
            }

            // Check if object has reached ground level
            if (obj.getY() <= ground_LEVEL) {
                objectsToRemove.add(obj);
                System.out.println("Object reached ground: " + obj);
            }
        }

        // Remove objects that have fallen completely
        girtihui__Objects.removeAll(objectsToRemove);
    }

    private void Collisionscheckkaro() {
        if (!kyaLaunchedhua) return;

        Rectangle birdBounds = new Rectangle(
            current______Bird.getX(),
            current______Bird.getY(),
            current______Bird.getWidth(),
            current______Bird.getHeight()
        );

        // Check collision with seeshas
        for (kanch kanch : new ArrayList<>(kanchList)) {
            Rectangle seeshaBounds = new Rectangle(
                kanch.getX(),
                kanch.getY(),
                kanch.getWidth(),
                kanch.getHeight()
            );

            if (birdBounds.overlaps(seeshaBounds)) {
                handleSeeshaCollision(kanch);
            }
        }

        // Check collision with suars
        for (Piggiess piggiess : new ArrayList<>(piggiessList)) {
            Rectangle suarBounds = new Rectangle(
                piggiess.getX(),
                piggiess.getY(),
                piggiess.getWidth(),
                piggiess.getHeight()
            );

            if (birdBounds.overlaps(suarBounds)) {
                handle___Suar___Collision(piggiess);
            }
        }
    }


    private void checkandupdatekarofallingobjectsko(Actor destroyedObject) {
        // Check seeshas that might now fall
        for (kanch kanch : new ArrayList<>(kanchList)) {
            if (kyaSupportRemovedhogya(kanch, destroyedObject)) {
                System.out.println("kanch detected falling: " + kanch);
                kanchList.remove(kanch);
                kanch.setVisible(false);
                kanch.girnachaluhua();  // Make sure this method exists
                girtihui__Objects.add(kanch);
            }
        }

        // Similar check for suars
        for (Piggiess piggiess : new ArrayList<>(piggiessList)) {
            if (kyaSupportRemovedhogya(piggiess, destroyedObject)) {
                System.out.println("Piggiess detected falling: " + piggiess);
                piggiessList.remove(piggiess);
                piggiess.setVisible(false);
                girtihui__Objects.add(piggiess);
            }
        }
    }

    // Helper method to check if an object has lost its support
    private boolean kyaSupportRemovedhogya(Actor object_to__check, Actor destroyed___Object) {
        Rectangle objectBounds = new Rectangle(
            object_to__check.getX(),
            object_to__check.getY(),
            object_to__check.getWidth(),
            object_to__check.getHeight()
        );

        Rectangle destroyedBounds = new Rectangle(
            destroyed___Object.getX(),
            destroyed___Object.getY(),
            destroyed___Object.getWidth(),
            destroyed___Object.getHeight()
        );

        // Enhanced check: If the destroyed object overlaps horizontally with the object we're checking
        // and the destroyed object was directly below the object
        return (destroyedBounds.x < objectBounds.x + objectBounds.width &&
            destroyedBounds.x + destroyedBounds.width > objectBounds.x &&
            destroyedBounds.y + destroyedBounds.height >= objectBounds.y &&
            destroyedBounds.y < objectBounds.y);
    }

    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(1, 1, 1, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        // Update bird animation
        update__bird________animation(delta);
        updatekarofallingobjects(delta);


        System.out.println("Bird Body Position: " +
            current______Bird.Bodykogetkaro().getPosition().x * PPM + ", " +
            current______Bird.Bodykogetkaro().getPosition().y * PPM);
        System.out.println("Bird Linear Velocity: " +
            current______Bird.Bodykogetkaro().getLinearVelocity());


        // Update bird's position if launched
        if (kyaLaunchedhua && !kyaAnimatinghorahihai) {
            System.out.println("Rendering bird at: " + positioon);
            // Ensure you're setting the bird's position precisely
            current______Bird.setPosition(positioon.x, positioon.y);

            launchTime += delta;

            positioon.x += speed.x * delta;
            positioon.y += speed.y * delta + 0.5f * gravity * delta * delta;

            // Check collisions
            Collisionscheckkaro();

            // If the bird reaches ground, stop motion and switch to next bird
            if (positioon.y <= 300) {
                kyaLaunchedhua = false;
                speed.y = 0;
                positioon.y = 300;
                kyaKhatamhua = true;
                current______Bird.setPosition(positioon.x, positioon.y);
                NextBird_pe_switch_karo();
            } else {
                speed.y += gravity * delta;
            }
        }

        world.step(delta, 6, 2);

        // Synchronize object positions with physics bodies
        ObjectPositionskoupdatekardo();

        // Optional: Render physics debug lines
        dDebugRenderer.render(world, platform.getCamera().combined);
        // Draw everything
        gamme.batttch.setProjectionMatrix(platform.getCamera().combined);
        gamme.batttch.begin();
        gamme.batttch.draw(Texturelogo, 0, 0, platform.getWidth(), platform.getHeight());
        gamme.batttch.end();

        // Draw the stage and trajectory if enabled
        platform.act();
        platform.draw();

        if (show___Trajectory) {
            shaperenderer.setProjectionMatrix(platform.getCamera().combined);
            drawTrajectory();
        }
    }



    private void initializekaroBirdsko() {
        redBird = new blackbird.redbird();
        redBird.setPosition(100, 300);
        redBird.setSize(redBird.getWidth() * 0.05f, redBird.getHeight() * 0.05f);

        redBird1 = new blackbird.redbird();
        redBird1.setPosition(200, 300);
        redBird1.setSize(redBird.getWidth(), redBird.getHeight());

        redBird2 = new blackbird.redbird();
        redBird2.setPosition(circleCenterX, circleCenterY);
        redBird2.setSize(redBird.getWidth(), redBird.getHeight());

        birds = new blackbird.redbird[]{redBird, redBird1, redBird2};
        current______Bird = birds[currentBirdIndex];

        // Store positions for animation
        start__Position.set(200, 300);
        end___Position.set(circleCenterX, circleCenterY);
    }

    private void initializekarooo__Objects() {
        catapult = new catapult();
        catapult.setPosition(300, 300);

        kanch1 = new kanch();
        kanch1.setPosition(1200, 360);
        kanch1.setRotation(90);
        kanch1.setSize(kanch1.getWidth() * 0.075f, kanch1.getHeight() * 0.075f);

        kanch2 = new kanch();
        kanch2.setPosition(1200, 490);
        kanch2.setRotation(90);
        kanch2.setSize(kanch1.getWidth(), kanch1.getHeight());

        kanch3 = new kanch();
        kanch3.setPosition(1200, 563);
        kanch3.setSize(kanch1.getWidth(), kanch1.getHeight());

        piggiess1 = new Piggiess();
        piggiess1.setPosition(1200, 580);
        piggiess1.setSize(piggiess1.getWidth() * 0.2f, piggiess1.getHeight() * 0.2f);

        piggiess2 = new Piggiess();
        piggiess2.setPosition(1300, 580);
        piggiess2.setSize(piggiess1.getWidth(), piggiess1.getHeight());
    }

    private void BirdInputListenerkosetupkaro() {
        InputListener birdListener = new InputListener() {
            @Override
            public boolean touchDown(InputEvent event, float x, float y, int pointer, int button) {
                if (kyaKhatamhua || kyaAnimatinghorahihai || event.getTarget() != current______Bird) return false;

                kyaDragginghorahihai = true;
                show___Trajectory = true;
                dragOffsetX = x;
                dragOffsetY = y;
                current______Bird.toFront();
                return true;
            }

            @Override
            public void touchDragged(InputEvent event, float x, float y, int pointer) {
                if (kyaLaunchedhua || kyaAnimatinghorahihai || event.getTarget() != current______Bird) return;

                if (kyaDragginghorahihai) {
                    float newX = event.getStageX() - dragOffsetX;
                    float newY = event.getStageY() - dragOffsetY;

                    newX = Math.min(newX, circleCenterX);
                    newY = Math.min(newY, circleCenterY);

                    float dx = newX - circleCenterX;
                    float dy = newY - circleCenterY;
                    float distance = (float) Math.sqrt(dx * dx + dy * dy);

                    if (distance > circleRadius) {
                        float scale = circleRadius / distance;
                        newX = circleCenterX + dx * scale;
                        newY = circleCenterY + dy * scale;
                    }

                    float velocityScale = distance / circleRadius;
                    float angle = (float) Math.atan2(circleCenterY - newY, circleCenterX - newX);
                    launch____Velocity.x = (float) Math.cos(angle) * MAXIMUM_VELOCITY * velocityScale;
                    launch____Velocity.y = (float) Math.sin(angle) * MAXIMUM_VELOCITY * velocityScale;

                    current______Bird.setPosition(newX, newY);
                }
            }

            @Override
            public void touchUp(InputEvent event, float x, float y, int pointer, int button) {
                if (kyaLaunchedhua || kyaAnimatinghorahihai || event.getTarget() != current______Bird) return;

                kyaDragginghorahihai = false;
                show___Trajectory = false;
                kyaLaunchedhua = true;
                launchTime = 0;
                positioon.set(current______Bird.getX(), current______Bird.getY());
                speed.set(launch____Velocity);

                // Debug prints
                System.out.println("Bird Launched!");
                System.out.println("Launch Position: " + positioon);
                System.out.println("Launch Velocity: " + speed);

                float startX = current______Bird.getX() + current______Bird.getWidth() / 2;
                float startY = current______Bird.getY() + current______Bird.getHeight() / 2;

                x = startX;
                y = startY;
                int i = 0;
                while(true) {
                    float t = i * 0.05f;
                    x = startX + launch____Velocity.x * t;
                    y = startY + launch____Velocity.y * t + 0.5f * gravity * t * t;

                    if (y <= 300) break;
                    current______Bird.isVisible();
                    i++;
                }
            }


        };

        // Add listener to all birds
        for (blackbird.redbird bird : birds) {
            bird.addListener(birdListener);
        }
    }

    private void ActorskoaddkaroToPlatform() {
        platform.addActor(catapult);
        platform.addActor(redBird);
        platform.addActor(redBird1);
        platform.addActor(redBird2);
        platform.addActor(kanch1);
        platform.addActor(kanch2);
        platform.addActor(kanch3);
        platform.addActor(piggiess1);
        platform.addActor(piggiess2);
    }

    private void setupkaroButtonsko() {
        // Create back button
        Texture backButtonTexture = new Texture(Gdx.files.internal("goback.png"));
        TextureRegionDrawable backDrawable = new TextureRegionDrawable(backButtonTexture);
        ImageButton backButton = new ImageButton(backDrawable);
        backButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                gamme.setScreen(new LevelkiScreenchunoo(gamme));
            }
        });

        // Create load button
        Texture loadButtonTexture = new Texture(Gdx.files.internal("savebutton.png"));
        TextureRegionDrawable loadDrawable = new TextureRegionDrawable(loadButtonTexture);
        ImageButton loadButton = new ImageButton(loadDrawable);
        loadButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                chidiaghussemainhai.Loaded____Level = 1;
            }
        });

        // Create restart button
        Texture restartButtonTexture = new Texture(Gdx.files.internal("restartbutton.png"));
        TextureRegionDrawable restartDrawable = new TextureRegionDrawable(restartButtonTexture);
        ImageButton restartButton = new ImageButton(restartDrawable);
        restartButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                gamme.setScreen(new pehlelevelkiscreenn(gamme));
            }
        });

        // Create close button
        Texture closeButtonTexture = new Texture(Gdx.files.internal("quitButtonFINAL.png"));
        TextureRegionDrawable closeDrawable = new TextureRegionDrawable(closeButtonTexture);
        ImageButton closeButton = new ImageButton(closeDrawable);
        closeButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                Gdx.app.exit();
            }
        });

        // Set button sizes and positions
        backButton.setSize(50, 50);
        loadButton.setSize(50, 50);
        restartButton.setSize(50, 50);
        closeButton.setSize(50, 50);

        backButton.setPosition(platform.getWidth() - 60, 10);
        loadButton.setPosition(platform.getWidth() - 120, 10);
        restartButton.setPosition(10, platform.getHeight() - 60);
        closeButton.setPosition(platform.getWidth() - 60, platform.getHeight() - 60);

        // Add buttons to stage
        platform.addActor(Tablemain);
        platform.addActor(backButton);
        platform.addActor(loadButton);
        platform.addActor(restartButton);
        platform.addActor(closeButton);
    }

    private void update__bird________animation(float delta) {
        if (kyaAnimatinghorahihai) {
            animationkaTime += delta;
            float progress = Math.min(animationkaTime / BOUNCE_duration, 1.0f);

            // Quadratic easing for smooth movement
            float x = start__Position.x + (end___Position.x - start__Position.x) * progress;

            // Add bounce effect using sine wave
            float bounceProgress = (float) Math.sin(progress * Math.PI);
            float bounceOffset = (1 - progress) * BOUNCE_height * bounceProgress;
            float y = start__Position.y + (end___Position.y - start__Position.y) * progress + bounceOffset;

            current______Bird.setPosition(x, y);

            // Animation complete
            if (progress >= 1.0f) {
                kyaAnimatinghorahihai = false;
                animationkaTime = 0f;
                current______Bird.setPosition(end___Position.x, end___Position.y);
                kyaKhatamhua = false; // Reset for the next bird
            }
        }
    }

    private void NextBird_pe_switch_karo() {
        if (currentBirdIndex > 0) {
            currentBirdIndex--;
            current______Bird = birds[currentBirdIndex];
            kyaAnimatinghorahihai = true;
            animationkaTime = 0f;
            start__Position.set(current______Bird.getX(), current______Bird.getY());
            kyaLaunchedhua = false;
            kyaKhatamhua = false;
            show___Trajectory = false;
        }
    }

    private void drawTrajectory() {
        if (!show___Trajectory) return;

        shaperenderer.begin(ShapeType.Filled);
        shaperenderer.setColor(1, 1, 1, 0.5f);

        float startX = current______Bird.getX() + current______Bird.getWidth() / 2;
        float startY = current______Bird.getY() + current______Bird.getHeight() / 2;

        int i = 0;
        while(true) {
            float t = i * 0.05f;
            float x = startX + launch____Velocity.x * t;
            float y = startY + launch____Velocity.y * t + 0.5f * gravity * t * t;

            if (y <= 300) break;
            shaperenderer.circle(x, y, 5);
            i++;
        }

        shaperenderer.end();
    }

    @Override
    public void resize(int width, int height) {
        platform.getViewport().update(width, height, true);
        Tablemain.setPosition(gameport.getWorldWidth() / 2, gameport.getWorldHeight() / 2 - 200);
    }

    @Override
    public void show() {}

    @Override
    public void pause() {}

    @Override
    public void resume() {}

    @Override
    public void hide() {}

    @Override
    public void dispose() {
        platform.dispose();
        Texturelogo.dispose();
        redBird.dispose();
        redBird1.dispose();
        redBird2.dispose();
        catapult.dispose();
        kanch1.dispose();
        kanch2.dispose();
        kanch3.dispose();
        piggiess1.dispose();
        piggiess2.dispose();
        shaperenderer.dispose();
        world.dispose();
        dDebugRenderer.dispose();
    }
}
