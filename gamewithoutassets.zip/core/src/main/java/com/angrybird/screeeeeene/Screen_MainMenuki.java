package com.angrybird.screeeeeene;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.angrybird.chidiaghussemainhai;

public class Screen_MainMenuki implements Screen {
    private final chidiaghussemainhai gaammmme;
    private Stage platform;

    public Screen_MainMenuki(chidiaghussemainhai gaammmme) {
        this.gaammmme = gaammmme;
        platform = new Stage();
        Gdx.input.setInputProcessor(platform);

        TextButton Buttonproceedkeliye = new TextButton("start", new TextButton.TextButtonStyle());

        Buttonproceedkeliye.addListener(new ClickListener() {
            @Override
            public void clicked(com.badlogic.gdx.scenes.scene2d.InputEvent event, float x, float y) {
                gaammmme.setScreen(new shuruatkiScreen(gaammmme));
            }
        });

        Table tabbllle = new Table();
        tabbllle.setFillParent(true);
        tabbllle.add(Buttonproceedkeliye).pad(10);

        platform.addActor(tabbllle);
    }

    @Override
    public void show() {}

    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(1, 1, 1, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        platform.act();
        platform.draw();
    }

    @Override
    public void resize(int width, int height) {
        platform.getViewport().update(width, height, true);
    }

    @Override
    public void pause() {}

    @Override
    public void resume() {}

    @Override
    public void hide() {}

    @Override
    public void dispose() {
        platform.dispose();
    }
}
