package com.angrybird.screeeeeene;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.viewport.StretchViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.angrybird.chidiaghussemainhai;

public class shuruatkiScreen implements Screen {
    private final chidiaghussemainhai gammeee;
    private Stage platform;
    private Texture Texturelogoka;
    private Texture closeButtonkeliyeTexture;
    private static final float LOADING_SCREEN_DURATION = 2.0f; // 2 seconds loading screen
    private float elapsedTime = 0f;
    private boolean isLoading = true;

    public static OrthographicCamera game__camerraa;
    public static Viewport game____port;

    public shuruatkiScreen(chidiaghussemainhai gammeee) {
        this.gammeee = gammeee;
        game__camerraa = new OrthographicCamera();
        game____port = new StretchViewport(1820, 980, game__camerraa);

        platform = new Stage(new StretchViewport(1820, 980));
        Gdx.input.setInputProcessor(platform);

        Texturelogoka = new Texture(Gdx.files.internal("LoadScreen.png"));
        closeButtonkeliyeTexture = new Texture(Gdx.files.internal("quitButtonFINAL.png"));

        TextureRegionDrawable closeDrawable = new TextureRegionDrawable(closeButtonkeliyeTexture);
        ImageButton closeButton = new ImageButton(closeDrawable);

        closeButton.addListener(new ClickListener() {
            @Override
            public void clicked(com.badlogic.gdx.scenes.scene2d.InputEvent event, float x, float y) {
                System.out.println("Close button clicked");
                Gdx.app.exit();
            }
        });

        platform.addActor(closeButton);
        closeButton.setSize(100, 100);
        closeButton.setPosition(platform.getWidth() - 110, platform.getHeight() - 110);
    }

    @Override
    public void show() {
        resize(Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
    }

    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(1, 1, 1, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        // Manage loading screen duration
        if (isLoading) {
            elapsedTime += delta;

            if (elapsedTime >= LOADING_SCREEN_DURATION) {
                isLoading = false;
                gammeee.setScreen(new LevelkiScreenchunoo(gammeee));
                return;
            }
        }

        gammeee.batttch.setProjectionMatrix(game__camerraa.combined);
        gammeee.batttch.begin();
        gammeee.batttch.draw(Texturelogoka, 0, 0, game____port.getWorldWidth(), game____port.getWorldHeight());
        gammeee.batttch.end();

        platform.act();
        platform.draw();
    }

    @Override
    public void resize(int width, int height) {
        game____port.update(width, height);
        game__camerraa.position.set(game____port.getWorldWidth() / 2, game____port.getWorldHeight() / 2, 0);
        platform.getViewport().update(width, height, true);
    }

    @Override
    public void pause() {}

    @Override
    public void resume() {}

    @Override
    public void hide() {}

    @Override
    public void dispose() {
        platform.dispose();
        Texturelogoka.dispose();
        closeButtonkeliyeTexture.dispose();
    }
}
