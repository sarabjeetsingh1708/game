package com.angrybird.screeeeeene;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.viewport.StretchViewport;
import com.angrybird.chidiaghussemainhai;
import com.badlogic.gdx.utils.viewport.Viewport;


public class JeetnekiScreen implements Screen {
    private final chidiaghussemainhai gaaame;
    private Stage platform;
    private Texture texturebackgrnd;
    private Texture texturequitButton;
    private Texture texturebackButton;

    public JeetnekiScreen(chidiaghussemainhai gaaame) {
        this.gaaame = gaaame;
        platform = new Stage(new StretchViewport(1820, 980));
        Gdx.input.setInputProcessor(platform);

        texturebackgrnd = new Texture(Gdx.files.internal("victoryscreen.png"));

        texturequitButton = new Texture(Gdx.files.internal("quitButtonFINAL.png"));
        TextureRegionDrawable quitDrawable = new TextureRegionDrawable(texturequitButton);
        ImageButton quitButton = new ImageButton(quitDrawable);
        quitButton.addListener(new ClickListener() {
            @Override
            public void clicked(com.badlogic.gdx.scenes.scene2d.InputEvent event, float x, float y) {
                Gdx.app.exit();
            }
        });
        quitButton.setSize(100, 100);
        quitButton.setPosition(platform.getWidth() - 110, platform.getHeight() - 110);

        texturebackButton = new Texture(Gdx.files.internal("goback.png"));
        TextureRegionDrawable Drawableback = new TextureRegionDrawable(texturebackButton);
        ImageButton backButton = new ImageButton(Drawableback);
        backButton.addListener(new ClickListener() {
            @Override
            public void clicked(com.badlogic.gdx.scenes.scene2d.InputEvent event, float x, float y) {
                gaaame.setScreen(new LevelkiScreenchunoo(gaaame));
            }
        });
        backButton.setSize(100, 100);
        backButton.setPosition(platform.getWidth() - 110, 20);

        platform.addActor(quitButton);
        platform.addActor(backButton);
    }

    @Override
    public void show() {}

    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(1, 1, 1, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        gaaame.batttch.setProjectionMatrix(platform.getCamera().combined);
        gaaame.batttch.begin();
        gaaame.batttch.draw(texturebackgrnd, 0, 0, platform.getWidth(), platform.getHeight());
        gaaame.batttch.end();

        platform.act();
        platform.draw();
    }

    @Override
    public void resize(int width, int height) {
        platform.getViewport().update(width, height, true);
    }

    @Override
    public void pause() {}

    @Override
    public void resume() {}

    @Override
    public void hide() {}

    @Override
    public void dispose() {
        platform.dispose();
        texturebackgrnd.dispose();
        texturequitButton.dispose();
        texturebackButton.dispose();
    }

    public static interface GussaelChidyaan {
    }

    public static class KhelnekiScreen implements Screen {
        private chidiaghussemainhai game;
        private OrthographicCamera gamecamera;
        private Viewport portgame;
        private Stage staaagge;

        public KhelnekiScreen(chidiaghussemainhai gaammme) {
            this.game = gaammme;
            gamecamera = new OrthographicCamera();
            portgame = new StretchViewport(1820, 980, gamecamera);
            staaagge = new Stage(portgame);
        }

        @Override
        public void show() {}

        @Override
        public void render(float delta) {
            Gdx.gl.glClearColor(1, 1, 0, 1);
            Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        }

        @Override
        public void resize(int widdttthhh, int heigghhht) {
            portgame.update(widdttthhh, heigghhht);
            gamecamera.position.set(portgame.getWorldWidth() / 2, portgame.getWorldHeight() / 2, 0);
            gamecamera.update();
            staaagge.getViewport().update(widdttthhh, heigghhht, true);
        }

        @Override
        public void pause() {}

        @Override
        public void resume() {}

        @Override
        public void hide() {}

        @Override
        public void dispose() {
            staaagge.dispose();
        }
    }
}
