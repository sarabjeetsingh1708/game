package com.angrybird;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.angrybird.screeeeeene.shuruatkiScreen;

/** {@link com.badlogic.gdx.ApplicationListener} implementation shared by all platforms. */
public class chidiaghussemainhai extends Game {

    public static final int widthh = 480;
    public static final int heightt = 208;
    public static Runtime.Version gameko__Port;
    public SpriteBatch batttch;
    public static int Loaded____Level = 1;

    @Override
    public void create() {
        batttch = new SpriteBatch();

        Gdx.graphics.setFullscreenMode(Gdx.graphics.getDisplayMode());

        setScreen(new shuruatkiScreen(this));
    }

    @Override
    public void render() {
        super.render();
    }

    @Override
    public void dispose() {
        batttch.dispose();
    }
}
