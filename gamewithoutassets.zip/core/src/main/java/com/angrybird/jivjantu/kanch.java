package com.angrybird.jivjantu;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.physics.box2d.Body;
import com.badlogic.gdx.scenes.scene2d.Actor;

public class kanch extends Actor {
    private Texture appearance;
    private boolean kyadestryhua = false;
    private boolean kyagirrhahai = false;

    private Body bodddddy;

    public void setBodddddy(Body bodddddy) {
        this.bodddddy = bodddddy;
    }

    public Body getBodddddy() {
        return bodddddy;
    }

    public kanch() {
        appearance = new Texture("glassplank.png");
        setSize(appearance.getWidth(), appearance.getHeight());
    }

    public void draw(Batch batch, float alpha) {
        if (!kyadestryhua) {
            batch.draw(appearance, getX(), getY(), getWidth() / 2, getHeight() / 2,
                getWidth(), getHeight(), 1, 1, getRotation(),
                0, 0, appearance.getWidth(), appearance.getHeight(), false, false);
        }
    }




    public void updddddate(float delta) {
        if (kyagirrhahai) {
            float newY = getY() - 300 * delta; // Falling speed

            if (newY <= 300) {
                newY = 300;
                kyagirrhahai = false;
                dessssstroy(); // Destroy when reaches ground
            }

            setY(newY);
        }
    }

    public void dessssstroy() {
        kyadestryhua = true;
        setVisible(false); // Completely remove from view
    }

    public void girnachaluhua() {
        kyagirrhahai = true;
    }

    public boolean isKyadestryhua() {
        return kyadestryhua;
    }

    public boolean isKyagirrhahai() {
        return kyagirrhahai;
    }

    // Other existing methods remain the same...


    public void dispose() {
        appearance.dispose();
    }

    public static class steelll extends Actor {
        private Texture appearannce;

        public steelll() {
            appearannce = new Texture("steelplank.png");
            setSize(appearannce.getWidth(), appearannce.getHeight());
        }

        @Override
        public void draw(Batch batch, float alpha) {
            batch.draw(appearannce, getX(), getY(), getWidth() / 2, getHeight() / 2,
                getWidth(), getHeight(), 1, 1, getRotation(),
                0, 0, appearannce.getWidth(), appearannce.getHeight(), false, false);
        }


        public void dispose() {
            appearannce.dispose();
        }
    }

    public static class woooood extends Actor {
        private Texture texture;

        public woooood() {
            texture = new Texture("woodplank.png");
            setSize(texture.getWidth(), texture.getHeight());
        }

        @Override
        public void draw(Batch batch, float alpha) {
            batch.draw(texture, getX(), getY(), getWidth() / 2, getHeight() / 2,
                getWidth(), getHeight(), 1, 1, getRotation(),
                0, 0, texture.getWidth(), texture.getHeight(), false, false);
        }


        public void dispose() {
            texture.dispose();
        }
    }
}


