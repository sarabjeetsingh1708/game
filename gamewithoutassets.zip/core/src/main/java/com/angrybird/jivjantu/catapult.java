package com.angrybird.jivjantu;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.scenes.scene2d.Actor;

public class catapult extends Actor {
    private Texture catapulttTexture;

    public catapult() {
        catapulttTexture = new Texture(Gdx.files.internal("slingshot.png"));
        setSize(catapulttTexture.getWidth(), catapulttTexture.getHeight());
    }

    @Override
    public void draw(Batch batch, float parentAlpha) {
        batch.draw(catapulttTexture, getX(), getY(), getWidth(), getHeight());
    }

    public void dispose() {
        catapulttTexture.dispose();
    }
}
