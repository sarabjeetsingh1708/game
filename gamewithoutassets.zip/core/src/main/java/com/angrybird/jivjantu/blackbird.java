package com.angrybird.jivjantu;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.physics.box2d.Body;
import com.badlogic.gdx.scenes.scene2d.Actor;

public class blackbird extends Actor {
    private Sprite sprite;

    public blackbird() {
        Texture texture = new Texture("blackchidiya.png");
        sprite = new Sprite(texture);
        setSize(sprite.getWidth(), sprite.getHeight());
    }

    @Override
    public void draw(Batch batch, float alpha) {
        sprite.setPosition(getX(), getY());
        sprite.setSize(getWidth(), getHeight());
        sprite.draw(batch, alpha);
    }

    //    @Override
    public void dispose() {
        sprite.getTexture().dispose();
    }

    public static class bluebird extends Actor {
        private Sprite sprite;

        public bluebird() {
            Texture texture = new Texture("BlueBird.png");
            sprite = new Sprite(texture);
            setSize(sprite.getWidth(), sprite.getHeight());
        }

        @Override
        public void draw(Batch batch, float alpha) {
            sprite.setPosition(getX(), getY());
            sprite.setSize(getWidth(), getHeight());
            sprite.draw(batch, alpha);
        }

        //    @Override
        public void dispose() {
            sprite.getTexture().dispose();
        }
    }

    public static class redbird extends Actor {
        private Sprite sprrrrite;
        private Body body;

        public redbird() {
            Texture texture = new Texture("Red.png");
            sprrrrite = new Sprite(texture);
            setSize(sprrrrite.getWidth(), sprrrrite.getHeight());
        }


        public void bodyset(Body body) {
            this.body = body;
        }

        public Body Bodykogetkaro() {
            return body;
        }

        @Override
        public void draw(Batch batch, float alpha) {
            sprrrrite.setPosition(getX(), getY());
            sprrrrite.setSize(getWidth(), getHeight());
            sprrrrite.draw(batch, alpha);
        }

    //    @Override
        public void dispose() {
            sprrrrite.getTexture().dispose();
        }


    }

    public static class yellowbird extends Actor {
        private Sprite sppprrrrite;

        public yellowbird() {
            // Load your texture here
            Texture texture = new Texture("YelloBird.png");
            sppprrrrite = new Sprite(texture);
            setSize(sppprrrrite.getWidth(), sppprrrrite.getHeight());
        }

        @Override
        public void draw(Batch batch, float alpha) {
            sppprrrrite.setPosition(getX(), getY());
            sppprrrrite.setSize(getWidth(), getHeight());
            sppprrrrite.draw(batch, alpha);
        }

        //    @Override
        public void dispose() {
            sppprrrrite.getTexture().dispose();
        }
    }
}
