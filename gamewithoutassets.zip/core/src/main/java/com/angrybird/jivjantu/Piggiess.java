package com.angrybird.jivjantu;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.physics.box2d.Body;
import com.badlogic.gdx.scenes.scene2d.Actor;

public class Piggiess extends Actor {
    private Texture appearance;
    private boolean kyanashthua = false;
    private boolean isFalling = false;
    private Body body;

    public void setBody(Body body) {
        this.body = body;
    }

    public Body getBody() {
        return body;
    }

    public Piggiess() {
        appearance = new Texture("piggy.png");
        setSize(appearance.getWidth(), appearance.getHeight());
    }

    @Override
    public void draw(Batch batch, float alpha) {
        if (!kyanashthua) {
            batch.draw(appearance, getX(), getY(), getWidth(), getHeight());
        }
    }

    public void updddddate(float delta) {
        if (isFalling) {
            float newY = getY() - 500f * delta;

            if (newY <= 300) {
                newY = 300;
                isFalling = false;
                desssssstroy(); // Destroy when reaches ground
            }

            setY(newY);
        }
    }

    public void desssssstroy() {
        kyanashthua = true;
        setVisible(false); // Completely remove from view
    }

    public void start____falling() {
        isFalling = true;
    }

    public boolean isKyanashthua() {
        return kyanashthua;
    }

    public boolean isFalling() {
        return isFalling;
    }

    // Other existing methods remain the same...

    public void dispose() {
        appearance.dispose();
    }
}
